g++ main.cpp tsp_algoritmos.cpp -o tsp -std=c++11
g++ main.cpp mochila_algoritmos.cpp -o mochila -std=c++11