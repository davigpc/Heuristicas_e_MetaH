g++ main.cpp simulated_annealing.cpp -o programa -std=c++11
./programa nome_do_arquivo.tsp